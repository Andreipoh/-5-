from note_manager.interface import user_interface
from note_manager.data import save_notes_to_file, append_notes_to_file,load_notes_from_file, save_notes_json
from note_manager.utils import validate_date, validate_status, generate_unique_id
