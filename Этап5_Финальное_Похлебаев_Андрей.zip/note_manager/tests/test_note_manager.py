import unittest

from note_manager.data import save_notes_to_file, load_notes_from_file



class TestNoteManager(unittest.TestCase):

    def test_save_and_load_notes(self):

        notes = [{'username': 'Test', 'title': 'Test Note'}]

        save_notes_to_file(notes, 'test_notes.txt')

        loaded_notes = load_notes_from_file('test_notes.txt')

        self.assertEqual(notes, loaded_notes)



if __name__ == '__main__':

    unittest.main()