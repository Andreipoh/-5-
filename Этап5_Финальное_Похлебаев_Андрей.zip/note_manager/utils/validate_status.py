from ast import Index
from itertools import count

from note_manager.data.load_notes_from_file import notes

statuses = ['выполнена', 'в процессе', 'отложено']
def validate_status(notes):
    try:
        for value in notes:
            if value['status'] in statuses:
                print(value['status'])
        return True

    except IndexError:
        return False

validate_status(notes)