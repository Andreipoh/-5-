from datetime import datetime
from itertools import count

from note_manager.data.load_notes_from_file import notes


def validate_date(date_str):
    try:
        datetime.strptime(date_str, '%d-%m-%Y')
        print(date_str)
        return True
    except ValueError:
         return False

count = 0
for value in notes:
    date_str = value['created_date']
    validate_date(date_str)
    count += 1


count = 0
for value in notes:
    date_str = value['issue_date']
    validate_date(date_str)
    count += 1
