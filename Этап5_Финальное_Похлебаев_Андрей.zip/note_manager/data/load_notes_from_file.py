
notes = []
def load_notes_from_file():
    try:
        with open('Notes Manager.txt', encoding= 'utf-8') as file:
            file.seek(0)
            info = file.readline()
            a = 0  # счетчик считанных заметок
            while "Заметка" in info:
                i = 0  # счетчик строк в заметке
                list_key = ['username', 'title', 'content', 'status', 'created_date', 'issue_date']
                note = {}  # создание словаря для заметок
                while i < 6:
                    info = file.readline()  # считываем текущую строку
                    info  = info.split(': ')  # делим строку по признаку - ': ', строки заносим в список
                    info  = info[1].split('\n')  # вторую строку списка делим строку по признаку - '\n '
                    note[list_key[i]] = info[0]
                    i += 1
                else:
                    notes.append(note)  # Добавление словаря с новой заметкой в список заметок
                    a += 1
                    info  = file.readline()  # считываем завершающую строку ("------------")
                    info  = file.readline()  # считываем следующую строку
            print(notes)

    except FileNotFoundError:
        print("Файл 'Notes Manager.txt не найден'.")
        with open('Notes Manager.txt', 'w', encoding='utf-8') as file:
            print('Создан новый файл. "Notes Manager.txt"')


load_notes_from_file()
