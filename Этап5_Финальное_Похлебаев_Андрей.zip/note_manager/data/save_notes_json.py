from note_manager.interface.user_interface import notes

import json

def save_notes_json(notes, filename):
    with open(filename, 'w', encoding='utf-8') as file:
        j_file = json.dump(notes, file, indent=4, ensure_ascii=False)



save_notes_json(notes, 'json_file.json')